# 碳捕集工艺包计算平台 — 前端

基于 **React + Vite + Ant Design** 的碳捕集（燃烧后胺法）工艺包可视化界面。
给定烟气参数与工艺设定后，界面展示各设备的**尺寸参数**与**运行数据**。

> 计算当前由 **mock 数据驱动**（数据结构与真实后端一致）。
> 后续接入你的实验数据（回归/代理模型）时，界面无需改动，只需把
> `src/api/client.ts` 里的 `USE_REAL_API` 改为 `true` 并启动后端。

## ⚠️ 最重要的一条（避免 MIME 报错）
**千万不要双击 `index.html` 打开！** 那样会用 `file://` 方式打开，浏览器会报
"Failed to load module script ... MIME type of text/html" 错误，页面空白。

本项目必须经过「开发服务器」访问。最省事的办法：**双击 `启动.bat`**。
它会自动安装依赖、启动服务、并打开浏览器到 `http://localhost:5173`。

## 在 Windows 上运行（两种方法）

### 方法一：一键启动（推荐，适合不想敲命令）
1. 把 `carbon-capture-ui` 文件夹解压到任意位置（例如桌面）。
2. **双击 `启动.bat`**。
3. 等待依赖安装完成，浏览器会自动打开 `http://localhost:5173`。

### 方法二：手动命令行
1. 打开文件夹，在地址栏输入 `cmd` 回车，或在 VS Code 终端选择 Command Prompt。
2. 执行：
   ```bat
   npm install
   npm run dev
   ```
3. 浏览器手动访问 `http://localhost:5173`。

## 目录结构
```
carbon-capture-ui/
  启动.bat            # Windows 一键启动脚本（双击即可）
  index.html          # 入口页（不要直接双击打开！）
  package.json
  vite.config.ts
  tsconfig.json
  src/
    types.ts          # 前后端共享数据契约（流股/单元/结果/参数）
    api/
      mockData.ts     # mock 计算（UI 联调用的近似数据）
      client.ts       # 计算服务调用（USE_REAL_API 开关）
    components/
      ParamPanel.tsx  # 左：工艺参数表单（含「填入示例」「重置」）
      Flowsheet.tsx   # 中：工艺流程图（示意）
      ResultsPanel.tsx# 右：结果看板（KPI/流股表/单元）
    App.tsx           # 布局与状态
```

## 对接真实后端（你的实验数据）
1. 准备后端（FastAPI + scikit-learn，见 `environment_setup.md`）。
2. 在 `vite.config.ts` 中配置代理：`server.proxy = { '/api': 'http://localhost:8000' }`。
3. 将 `src/api/client.ts` 中 `USE_REAL_API` 改为 `true`。
4. 后端返回的 JSON 需与 `src/types.ts` 的 `CalcResult` 结构一致。

## 说明
- 流程图与数值当前为示意/mock，不代表真实物性计算结果。
- 真实物料/能量衡算将由你的实验数据回归模型提供。
