import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// 后端就绪后，可在此配置代理：
// server: { proxy: { '/api': 'http://localhost:8000' } }
export default defineConfig({
  plugins: [react()],
  server: { port: 5173, host: true }
})
