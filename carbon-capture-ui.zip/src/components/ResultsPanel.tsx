import { Card, Tabs, Table, Tag, Statistic, Row, Col, Empty } from 'antd'
import { CalcResult, Stream } from '../types'

interface Props {
  result: CalcResult | null
}

const streamColumns = [
  { title: '编号', dataIndex: 'id', key: 'id', width: 60 },
  { title: '名称', dataIndex: 'name', key: 'name' },
  {
    title: '相态', dataIndex: 'phase', key: 'phase', width: 80,
    render: (v: string) => <Tag color={v === 'Vapor' ? 'blue' : 'green'}>{v}</Tag>
  },
  { title: '摩尔流 (kmol/h)', dataIndex: 'molar_flow', key: 'molar_flow' },
  { title: '质量流 (kg/h)', dataIndex: 'mass_flow', key: 'mass_flow' },
  { title: '温度 (K)', dataIndex: 'temperature', key: 'temperature' },
  { title: '压力 (bar)', dataIndex: 'pressure', key: 'pressure' },
  {
    title: '主要组分', key: 'components',
    render: (_: any, r: Stream) =>
      Object.entries(r.components)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3)
        .map(([k, v]) => `${k}:${v.toFixed(1)}`)
        .join('  ')
  }
]

export default function ResultsPanel({ result }: Props) {
  if (!result) {
    return (
      <Card title="计算结果" size="small">
        <Empty description="设定参数后点击「计算」" />
      </Card>
    )
  }

  const kpi = (
    <Row gutter={16}>
      <Col span={6}><Card size="small"><Statistic title="CO₂ 脱除率" value={result.co2_removal} suffix="%" valueStyle={{ color: '#1677ff' }} /></Card></Col>
      <Col span={6}><Card size="small"><Statistic title="比能耗" value={result.specific_energy} suffix="GJ/t" /></Card></Col>
      <Col span={6}><Card size="small"><Statistic title="蒸汽耗" value={result.utilities.steam} suffix="t/h" /></Card></Col>
      <Col span={6}><Card size="small"><Statistic title="电耗" value={result.utilities.power} suffix="kW" /></Card></Col>
    </Row>
  )

  const items = [
    {
      key: 'kpi', label: '关键指标', children: (
        <>
          {kpi}
          <div style={{ marginTop: 12 }}>
            <Tag color={result.solved ? 'success' : 'error'}>
              {result.solved ? '求解成功' : '求解失败'}
            </Tag>
            {result.message && <span style={{ color: '#999' }}>{result.message}</span>}
            <div style={{ marginTop: 6, color: '#666' }}>案例编号：{result.case_id}</div>
          </div>
        </>
      )
    },
    {
      key: 'streams', label: `流股表 (${result.streams.length})`,
      children: <Table rowKey="id" size="small" columns={streamColumns} dataSource={result.streams} pagination={false} />
    },
    {
      key: 'units', label: `单元 (${result.units.length})`,
      children: (
        <Table rowKey="id" size="small" pagination={false} dataSource={result.units}
          columns={[
            { title: '编号', dataIndex: 'id', key: 'id' },
            { title: '名称', dataIndex: 'name', key: 'name' },
            { title: '类型', dataIndex: 'type', key: 'type' },
            { title: '热负荷 (kW)', dataIndex: 'duty', key: 'duty', render: (v: number | null) => v ?? '—' },
            { title: '状态', dataIndex: 'status', key: 'status', render: (v: string) => <Tag color="cyan">{v}</Tag> }
          ]}
        />
      )
    }
  ]

  return (
    <Card title="计算结果" size="small">
      <Tabs items={items} />
    </Card>
  )
}
