import { Form, InputNumber, Select, Button, Card, Divider, Space } from 'antd'
import { PlayCircleOutlined, ThunderboltOutlined } from '@ant-design/icons'
import { CalcParams } from '../types'

const AMINES = [
  { value: 'MEA', label: 'MEA（单乙醇胺）' },
  { value: 'DEA', label: 'DEA（二乙醇胺）' },
  { value: 'MDEA', label: 'MDEA（N-甲基二乙醇胺）' }
]

interface Props {
  loading: boolean
  onCalculate: (p: CalcParams) => void
}

export default function ParamPanel({ loading, onCalculate }: Props) {
  const [form] = Form.useForm<CalcParams>()

  // 交互①：一键填入示例工况，并立即计算
  const fillExample = () => {
    const ex: CalcParams = {
      flue_gas_flow: 1500, co2_inlet: 0.14, amine_type: 'MEA', amine_conc: 30,
      absorber_stages: 14, stripper_stages: 9, regen_temp: 398, lean_loading: 0.22
    }
    form.setFieldsValue(ex) // 改状态（表单值）
    onCalculate(ex)         // 立刻触发计算 → 右侧结果更新
  }

  // 交互②：重置回默认值
  const resetForm = () => form.resetFields()

  return (
    <Card title="工艺参数" size="small" style={{ height: '100%', overflow: 'auto' }}>
      <Form
        form={form}
        layout="vertical"
        initialValues={{
          flue_gas_flow: 1000,
          co2_inlet: 0.12,
          amine_type: 'MEA',
          amine_conc: 30,
          absorber_stages: 12,
          stripper_stages: 8,
          regen_temp: 393,
          lean_loading: 0.25
        }}
        onFinish={onCalculate}
      >
        <Divider orientation="left" plain>烟气条件</Divider>
        <Form.Item label="烟气量 (kmol/h)" name="flue_gas_flow" rules={[{ required: true }]}>
          <InputNumber min={1} max={100000} style={{ width: '100%' }} />
        </Form.Item>
        <Form.Item label="入口 CO₂ 摩尔分数" name="co2_inlet" rules={[{ required: true }]}>
          <InputNumber min={0.01} max={0.5} step={0.01} style={{ width: '100%' }} />
        </Form.Item>

        <Divider orientation="left" plain>吸收剂</Divider>
        <Form.Item label="胺类型" name="amine_type" rules={[{ required: true }]}>
          <Select options={AMINES} />
        </Form.Item>
        <Form.Item label="胺质量浓度 (%)" name="amine_conc" rules={[{ required: true }]}>
          <InputNumber min={5} max={60} style={{ width: '100%' }} />
        </Form.Item>
        <Form.Item label="贫液负载 (mol/mol)" name="lean_loading" rules={[{ required: true }]}>
          <InputNumber min={0.05} max={0.5} step={0.01} style={{ width: '100%' }} />
        </Form.Item>

        <Divider orientation="left" plain>设备</Divider>
        <Form.Item label="吸收塔理论级数" name="absorber_stages" rules={[{ required: true }]}>
          <InputNumber min={1} max={40} style={{ width: '100%' }} />
        </Form.Item>
        <Form.Item label="再生塔理论级数" name="stripper_stages" rules={[{ required: true }]}>
          <InputNumber min={1} max={40} style={{ width: '100%' }} />
        </Form.Item>
        <Form.Item label="再生温度 (K)" name="regen_temp" rules={[{ required: true }]}>
          <InputNumber min={360} max={450} style={{ width: '100%' }} />
        </Form.Item>

        <Button type="primary" htmlType="submit" loading={loading} block icon={<PlayCircleOutlined />}>
          计算
        </Button>
        <div style={{ height: 8 }} />
        <Space style={{ width: '100%' }}>
          <Button block onClick={fillExample} icon={<ThunderboltOutlined />}>填入示例工况</Button>
          <Button block onClick={resetForm}>重置</Button>
        </Space>
      </Form>
    </Card>
  )
}
