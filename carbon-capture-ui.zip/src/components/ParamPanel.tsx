import { Form, InputNumber, Select, Button, Card, Space, Alert } from 'antd'
import {
  PlayCircleOutlined,
  ThunderboltOutlined,
  ReloadOutlined,
  EnvironmentOutlined,
  ExperimentOutlined,
  SettingOutlined
} from '@ant-design/icons'
import { CalcParams } from '../types'

const AMINES = [
  { value: 'MEA', label: 'MEA（单乙醇胺）' },
  { value: 'DEA', label: 'DEA（二乙醇胺）' },
  { value: 'MDEA', label: 'MDEA（N-甲基二乙醇胺）' }
]

const Section = ({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) => (
  <div className="section-title">
    {icon}
    {children}
  </div>
)

interface Props {
  loading: boolean
  onCalculate: (p: CalcParams) => void
}

export default function ParamPanel({ loading, onCalculate }: Props) {
  const [form] = Form.useForm<CalcParams>()

  // 交互①：一键填入示例工况，并立即计算
  const fillExample = () => {
    const ex: CalcParams = {
      flue_gas_flow: 1500, co2_inlet: 0.14, amine_type: 'MEA', amine_conc: 30,
      absorber_stages: 14, stripper_stages: 9, regen_temp: 398, lean_loading: 0.22
    }
    form.setFieldsValue(ex) // 改状态（表单值）
    onCalculate(ex)         // 立刻触发计算 → 右侧结果更新
  }

  // 交互②：重置回默认值
  const resetForm = () => form.resetFields()

  return (
    <Card
      size="small"
      style={{ height: '100%', overflow: 'auto', borderTop: '3px solid #0d9488' }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
        <ExperimentOutlined style={{ fontSize: 18, color: '#0d9488' }} />
        <span style={{ fontSize: 15, fontWeight: 700, color: '#1f2937' }}>工艺参数</span>
      </div>
      <div style={{ color: '#9ca3af', fontSize: 12, marginBottom: 4 }}>
        设定工况后点击「计算」，右侧即时给出设备尺寸与运行数据
      </div>

      <Form
        form={form}
        layout="vertical"
        initialValues={{
          flue_gas_flow: 1000,
          co2_inlet: 0.12,
          amine_type: 'MEA',
          amine_conc: 30,
          absorber_stages: 12,
          stripper_stages: 8,
          regen_temp: 393,
          lean_loading: 0.25
        }}
        onFinish={onCalculate}
      >
        <Section icon={<EnvironmentOutlined />}>烟气条件</Section>
        <Form.Item label="烟气量 (kmol/h)" name="flue_gas_flow" rules={[{ required: true }]}>
          <InputNumber min={1} max={100000} style={{ width: '100%' }} />
        </Form.Item>
        <Form.Item label="入口 CO₂ 摩尔分数" name="co2_inlet" rules={[{ required: true }]}>
          <InputNumber min={0.01} max={0.5} step={0.01} style={{ width: '100%' }} />
        </Form.Item>

        <Section icon={<ExperimentOutlined />}>吸收剂</Section>
        <Form.Item label="胺类型" name="amine_type" rules={[{ required: true }]}>
          <Select options={AMINES} />
        </Form.Item>
        <Form.Item label="胺质量浓度 (%)" name="amine_conc" rules={[{ required: true }]}>
          <InputNumber min={5} max={60} style={{ width: '100%' }} />
        </Form.Item>
        <Form.Item label="贫液负载 (mol/mol)" name="lean_loading" rules={[{ required: true }]}>
          <InputNumber min={0.05} max={0.5} step={0.01} style={{ width: '100%' }} />
        </Form.Item>

        <Section icon={<SettingOutlined />}>设备</Section>
        <Form.Item label="吸收塔理论级数" name="absorber_stages" rules={[{ required: true }]}>
          <InputNumber min={1} max={40} style={{ width: '100%' }} />
        </Form.Item>
        <Form.Item label="再生塔理论级数" name="stripper_stages" rules={[{ required: true }]}>
          <InputNumber min={1} max={40} style={{ width: '100%' }} />
        </Form.Item>
        <Form.Item label="再生温度 (K)" name="regen_temp" rules={[{ required: true }]}>
          <InputNumber min={360} max={450} style={{ width: '100%' }} />
        </Form.Item>

        <Button
          type="primary"
          htmlType="submit"
          loading={loading}
          block
          size="large"
          icon={<PlayCircleOutlined />}
          style={{ marginTop: 6, height: 42, fontWeight: 600 }}
        >
          计算
        </Button>
        <div style={{ height: 10 }} />
        <Space style={{ width: '100%' }}>
          <Button block icon={<ThunderboltOutlined />} onClick={fillExample}>
            填入示例工况
          </Button>
          <Button block icon={<ReloadOutlined />} onClick={resetForm}>
            重置
          </Button>
        </Space>

        <Alert
          type="info"
          showIcon
          style={{ marginTop: 14, borderRadius: 8, fontSize: 12 }}
          message="当前为演示(mock)数据，接入你的实验数据后自动替换为真实计算值。"
        />
      </Form>
    </Card>
  )
}
