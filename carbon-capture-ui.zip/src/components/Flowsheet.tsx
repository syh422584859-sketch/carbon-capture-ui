import { Card } from 'antd'
import { ExperimentOutlined } from '@ant-design/icons'

// 简化的碳捕集流程图（燃烧后胺法：吸收塔 + 再生塔 + 再沸器 + 贫富液换热）
// 示意用，仅标注主要设备与物流走向；真实 PFD 由后端/工艺人员绘制。
export default function Flowsheet() {
  const box = (
    x: number,
    y: number,
    w: number,
    h: number,
    label: string,
    fill: string,
    stroke: string,
    textColor: string
  ) => (
    <>
      <rect x={x} y={y} width={w} height={h} rx={8} fill={fill} stroke={stroke} strokeWidth={1.6} />
      <text x={x + w / 2} y={y + h / 2 + 5} textAnchor="middle" fontSize={13} fontWeight={600} fill={textColor}>
        {label}
      </text>
    </>
  )
  const arrow = (x1: number, y1: number, x2: number, y2: number, label?: string) => (
    <>
      <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="#94a3b8" strokeWidth={1.6} markerEnd="url(#ah)" />
      {label && (
        <text x={(x1 + x2) / 2} y={(y1 + y2) / 2 - 5} textAnchor="middle" fontSize={11} fill="#475569">
          {label}
        </text>
      )}
    </>
  )

  return (
    <Card
      size="small"
      style={{ borderTop: '3px solid #0d9488' }}
      title={
        <span>
          <ExperimentOutlined style={{ color: '#0d9488', marginRight: 6 }} />
          工艺流程图（示意）
        </span>
      }
    >
      <svg viewBox="0 0 720 380" width="100%" style={{ background: '#f8fafc', borderRadius: 10 }}>
        <defs>
          <marker id="ah" markerWidth="10" markerHeight="10" refX="8" refY="3"
            orient="auto" markerUnits="strokeWidth">
            <path d="M0,0 L8,3 L0,6 Z" fill="#94a3b8" />
          </marker>
        </defs>

        {/* 设备（吸收侧青绿，再生侧蓝青，换热/再沸中性） */}
        {box(30, 160, 90, 56, '烟气进口', '#ccfbf1', '#0d9488', '#0f766e')}
        {box(170, 110, 70, 170, '吸收塔', '#ccfbf1', '#0d9488', '#0f766e')}
        {box(300, 40, 95, 44, '净化气', '#ecfeff', '#0ea5e9', '#0369a1')}
        {box(330, 300, 110, 50, '贫富液换热器', '#f1f5f9', '#64748b', '#334155')}
        {box(520, 110, 70, 170, '再生塔', '#cffafe', '#06b6d4', '#0e7490')}
        {box(630, 40, 80, 44, 'CO₂ 产品', '#ecfeff', '#0ea5e9', '#0369a1')}
        {box(500, 300, 110, 50, '再沸器', '#f1f5f9', '#64748b', '#334155')}

        {/* 物流 */}
        {arrow(120, 188, 170, 188, 'S1 烟气')}
        {arrow(240, 130, 300, 62, 'S2 净化气')}
        {arrow(240, 280, 330, 320, 'S3 富液')}
        {arrow(440, 320, 520, 200, 'S3→再生')}
        {arrow(590, 130, 630, 62, 'S5 CO₂')}
        {arrow(520, 290, 500, 325)}
        {arrow(390, 250, 170, 250, 'S4 贫液')}
        {arrow(555, 290, 555, 270)}
      </svg>
    </Card>
  )
}
