import { useState } from 'react'
import { Layout, App as AntdApp, Tag } from 'antd'
import { EnvironmentOutlined } from '@ant-design/icons'
import ParamPanel from './components/ParamPanel'
import Flowsheet from './components/Flowsheet'
import ResultsPanel from './components/ResultsPanel'
import { runCalculation } from './api/client'
import { CalcParams, CalcResult } from './types'

const { Header, Sider, Content } = Layout

export default function App() {
  const { message } = AntdApp.useApp()
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<CalcResult | null>(null)

  const handleCalculate = async (params: CalcParams) => {
    setLoading(true)
    try {
      const res = await runCalculation(params)
      setResult(res)
    } catch (e: any) {
      message.error(e?.message || '计算失败')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Layout style={{ minHeight: '100vh', background: 'transparent' }}>
      <Header
        className="app-header"
        style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          padding: '0 24px',
          height: 64,
          lineHeight: 'normal'
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <EnvironmentOutlined style={{ fontSize: 26, color: '#fff' }} />
          <div>
            <div style={{ color: '#fff', fontSize: 18, fontWeight: 700, lineHeight: 1.15 }}>
              碳捕集工艺包计算平台
            </div>
            <div style={{ color: 'rgba(255,255,255,0.78)', fontSize: 12 }}>
              Carbon Capture Process Package · 设计计算
            </div>
          </div>
        </div>
        <Tag
          color="rgba(255,255,255,0.18)"
          style={{ color: '#fff', border: 'none', borderRadius: 20, padding: '2px 12px' }}
        >
          演示模式 · Mock
        </Tag>
      </Header>

      <Layout>
        <Sider
          width={340}
          className="app-sider"
          style={{
            background: '#fff',
            borderRight: '1px solid #eef2f2',
            padding: 16,
            overflow: 'auto'
          }}
        >
          <ParamPanel loading={loading} onCalculate={handleCalculate} />
        </Sider>

        <Content style={{ padding: 16, overflow: 'auto' }}>
          <Flowsheet />
          <div style={{ height: 16 }} />
          <ResultsPanel result={result} />
        </Content>
      </Layout>
    </Layout>
  )
}
