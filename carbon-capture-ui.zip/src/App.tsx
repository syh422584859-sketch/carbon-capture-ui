import { useState } from 'react'
import { Layout, Typography, message as antdMessage } from 'antd'
import ParamPanel from './components/ParamPanel'
import Flowsheet from './components/Flowsheet'
import ResultsPanel from './components/ResultsPanel'
import { runCalculation } from './api/client'
import { CalcParams, CalcResult } from './types'

const { Header, Sider, Content } = Layout

export default function App() {
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<CalcResult | null>(null)

  const handleCalculate = async (params: CalcParams) => {
    setLoading(true)
    try {
      const res = await runCalculation(params)
      setResult(res)
    } catch (e: any) {
      antdMessage.error(e?.message || '计算失败')
    } finally {
      setLoading(false)
    }
  }

  return (
    <Layout style={{ height: '100vh' }}>
      <Header style={{ background: '#001529', display: 'flex', alignItems: 'center' }}>
        <Typography.Title level={4} style={{ color: '#fff', margin: 0 }}>
          碳捕集工艺包计算平台
        </Typography.Title>
      </Header>
      <Layout>
        <Sider width={320} theme="light" style={{ padding: 12, background: '#fff' }}>
          <ParamPanel loading={loading} onCalculate={handleCalculate} />
        </Sider>
        <Content style={{ padding: 12, overflow: 'auto' }}>
          <Flowsheet />
          <div style={{ height: 12 }} />
          <ResultsPanel result={result} />
        </Content>
      </Layout>
    </Layout>
  )
}
