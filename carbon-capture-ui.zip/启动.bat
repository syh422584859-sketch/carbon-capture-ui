@echo off
chcp 65001 >nul
title 碳捕集工艺包 - 一键启动
cd /d "%~dp0"

echo ============================================
echo   碳捕集工艺包 UI  -  一键启动
echo ============================================
echo.
echo  [1/2] 正在检查并安装依赖（首次运行需 1~3 分钟，请耐心等待）...
echo.
call npm install
if errorlevel 1 (
    echo.
    echo  [错误] npm install 失败，请确认已安装 Node.js（https://nodejs.org）。
    echo         安装后请重新运行本脚本。
    pause
    exit /b 1
)

echo.
echo  [2/2] 正在启动开发服务器...
echo.
start "Vite 开发服务器 (请勿关闭此窗口)" cmd /k "npm run dev"

echo  服务器启动中，5 秒后自动打开浏览器...
timeout /t 5 >nul
start "" http://localhost:5173

echo.
echo  ============================================
echo   浏览器已打开 http://localhost:5173
echo   如果浏览器没反应，请手动在地址栏输入上面的地址。
echo   用完关闭两个黑色窗口即可。
echo  ============================================
echo.
pause
